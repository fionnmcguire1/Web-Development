'use strict';
module.exports = function(sequelize, DataTypes) {
  var Courtroom = sequelize.define('Courtroom', {
    //id: DataTypes.SERIAL,
    number: DataTypes.STRING
  }, {
    classMethods: {
      associate: function(models) {
        // associations can be defined here
        //Courtroom.hasOne(models.Cases);
      }
    }
  });
  return Courtroom;
};