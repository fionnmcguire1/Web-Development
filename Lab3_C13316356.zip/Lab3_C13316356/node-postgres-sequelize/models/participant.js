'use strict';
module.exports = function(sequelize, DataTypes) {
  var Participant = sequelize.define('Participant', {
    //id: DataTypes.SERIAL,
    name: DataTypes.STRING,
    address: DataTypes.STRING,
    claimant: DataTypes.STRING
  }, {
    classMethods: {
      associate: function(models) {
        // associations can be defined here
      }
    }
  });
  return Participant;
};