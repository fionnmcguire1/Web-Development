'use strict';
module.exports = function(sequelize, DataTypes) {
  var Cases = sequelize.define('Cases', {
    judge_id: DataTypes.INTEGER,
    courtroom_id: DataTypes.INTEGER,
    claimant_id: DataTypes.INTEGER,
    respondent_id: DataTypes.INTEGER,
    start_date: DataTypes.DATE,    
    result: DataTypes.BOOLEAN
    //duration: DataTypes.INTERVAL,
  }, {
    classMethods: {
      associate: function(models) {
        // associations can be defined here
       // Cases.belongsTo(models.Courtroom);
      }
    }
  });
  return Cases;
};