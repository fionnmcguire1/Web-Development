// *** main dependencies *** //
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var swig = require('swig');
var jwt = require('jsonwebtoken');
var expressJWT = require('express-jwt');
const base64url = require('base64url');
//var bodyParser = require('body-parser');

///////////////////////////////
var http = require('http');
var massive = require("massive");
var connectionString = "postgres://postgres:flames@localhost/Courts";
var massiveInstance = massive.connectSync({connectionString : connectionString}) 
///////////////////////////////
// *** routes *** //
var routes = require('./routes/index.js');


// *** express instance *** //
var app = express();

app.use(expressJWT({ secret: 'DaVinci'}).unless({ path: ['/login','/','/get_users','/get_cases','/get_courtroom','/login2'] }));
//,'/get_judge'
//JWT login


app.get('/login', (req, res) => {
   
		//console.log(req.query)
		let uname = req.query.username || {} ;
		let pass = req.query.password || {} ;
		if(pass !=null && uname !=null)
		{
        massiveInstance.run("SELECT password = crypt('"+pass+"', password) AS authentication from \"Users\" WHERE username = '"+uname+"';" , (err,results) =>{
        if(results.length != 0){
        if(results[0].authentication == true)
        {
        	//res.send(results);
        	//res.send("Success!");
        	var mytoken = jwt.sign({ exp: Math.floor(Date.now() / 1000) + (60 * 60), username: uname}, 'DaVinci');
        	//var decoded = jwt.verify(req.get('Authorization'), "DaVinci", { algorithms: ['HS512'] });
        	//req.setRequestHeader('Authorization','Bearer ' + mytoken);
        	
			//var auth = 'Bearer ' + new Buffer(mytoken);
			// auth is: 'Basic VGVzdDoxMjM='
			//var header = {'Host': 'http://localhost:5001', 'Authorization': auth};
			
			var decoded = jwt.verify(mytoken, 'DaVinci');
        	//In here print the expiry timestamp and user id
			//res.status(200).json(base64url.decode(mytoken));
			res.status(200).json(mytoken);

        }
        else
        {
        //res.send(results);
        	res.send("Invalid Password/Username");
        }
        }
		
	
    });
    }
    else
    {
    	res.send("Invalid Password/Username");
    }
});


//HMAC

const crypto = require('crypto');


//console.log(hash);
app.get('/login2', (req, res) => {

const secret = 'DaVinci';
const hash = crypto.createHmac('sha256', secret).update('password').digest('hex');
res.send(hash);






});
//Query: SELECT password = crypt('@', password) FROM Users WHERE username = 'fionnmcguire';" , [query]


/*
['/update_judge/','/update_courtroom/','/update_cases/','/update_participant/','/delete_participant/',
'/delete_judge/', '/delete_courtroom/', '/delete_cases/', '/judge','/cases', '/participant', '/courtroom']

if(!results)
        {
        	res.send("Invalid Password/Username");
        }
        else 
*/


// *** view engine *** //
var swig = new swig.Swig();
app.engine('html', swig.renderFile);
app.set('view engine', 'html');


// *** static directory *** //
app.set('views', path.join(__dirname, 'views'));


// *** config middleware *** //
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../client')));


// *** main routes *** //
app.use('/', routes);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});


// *** error handlers *** //

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
