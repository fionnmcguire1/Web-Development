var express = require('express');
var models = require('../../models/index');
var router = express.Router();


router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


/*
//JWT login
router.get('/login', function(req, res) {
models.Users.query(" SELECT password = crypt(':pass', password) FROM Users where username = ':uname';",
  { replacements: { pass: 'password', uname: 'fionnmcguire'  }, type: models.Users.QueryTypes.SELECT }
).then(function(users) {
	res.json(users)
})
});*/






//Inserting
router.post('/judge', function(req, res) {
  models.Judge.create({
    name: req.body.name,
    room: req.body.room,
    ext: req.body.ext
  }).then(function(judge) {
    res.json(judge);
  });
});

router.post('/cases', function(req, res) {
  models.Cases.create({
    judge_id: req.body.judge_id,
    courtroom_id: req.body.courtroom_id,
    claimant_id:req.body.claimant_id,
    respondent_id: req.body.respondent_id,
    start_date: req.body.start_date,
    //duration: DataTypes.INTERVAL,
    result: req.body.result   
  }).then(function(cases) {
    res.json(cases);
  });
});

router.post('/courtroom', function(req, res) {
  models.Courtroom.create({
    number: req.body.number
  }).then(function(courtroom) {
    res.json(courtroom);
  });
});

router.post('/participant', function(req, res) {
  models.Participant.create({
    name: req.body.name,
    address: req.body.address,
    claimant: req.body.claimant
  }).then(function(participant) {
    res.json(participant);
  });
});



//Retreiving
router.get('/get_judge', function(req, res) {
//var decoded = jwt.verify(mytoken, 'DaVinci');
  models.Judge.findAll({}).then(function(judge) {
    res.json(judge);
  });
  
  
});

router.get('/get_users', function(req, res) {
  models.Users.findAll({}).then(function(users) {
    res.json(users);
  });
});

router.get('/get_judge/:id', function(req, res) {
  models.Judge.find({
  where: {
       id: req.params.id
       } 
    }).then(function(judge) {
    res.json(judge);
  });
});



router.get('/get_cases', function(req, res) {
  models.Cases.findAll({}).then(function(cases) {
    res.json(cases);
  });
});

router.get('/get_cases/:id', function(req, res) {
  models.Cases.find({
  where: {
      id: req.params.id
      }
    }).then(function(cases) {
    res.json(cases);
  });
});




router.get('/get_courtroom', function(req, res) {
  models.Courtroom.findAll({}).then(function(courtroom) {
    res.json(courtroom);
  });
});

router.get('/get_courtroom/:id', function(req, res) {
  models.Courtroom.find({
  where: {
      id: req.params.id
      }
    }).then(function(courtroom) {
    res.json(courtroom);
  });
});

router.get('/get_participant', function(req, res) {
  models.Participant.findAll({}).then(function(participant) {
    res.json(participant);
  });
});

router.get('/get_participant/:id', function(req, res) {
  models.Participant.find({
  where: {
      id: req.params.id
      }
    }).then(function(participant) {
    res.json(participant);
  });
});

//Update
router.put('/update_courtroom/:id', function(req, res) {
  models.Courtroom.find({
  where: {
      id: req.params.id
      }
    }).then(function(courtroom) {
    if(courtroom){
      courtroom.updateAttributes({
        number: req.body.number
      }).then(function(courtroom) {
        res.send(courtroom);
      });
    }
  });
});

router.put('/update_judge/:id', function(req, res) {
  models.Judge.find({
  where: {
      id: req.params.id
      }
    }).then(function(judge) {
    if(judge){
      judge.updateAttributes({
        name: req.body.name,
    	room: req.body.room,
    	ext: req.body.ext
      }).then(function(judge) {
        res.send(judge);
      });
    }
  });
});


router.put('/update_cases/:id', function(req, res) {
  models.Cases.find({
  where: {
      id: req.params.id
      }
    }).then(function(cases) {
    if(cases){
    cases.updateAttributes({
          judge_id: req.body.judge_id,
    	courtroom_id: req.body.courtroom_id,
    	claimant_id:req.body.claimant_id,
    	respondent_id: req.body.respondent_id,
   	 	start_date: req.body.start_date,
   		 //duration: DataTypes.INTERVAL,
    	result: req.body.result  
      }).then(function(cases) {
        res.send(cases);
      });
    }
  });
});

router.put('/update_participant/:id', function(req, res) {
  models.Participant.find({
  where: {
      id: req.params.id
      }
    }).then(function(participant) {
    if(participant){
      participant.updateAttributes({
            name: req.body.name,
    		address: req.body.address,
    		claimant: req.body.claimant
      }).then(function(participant) {
        res.send(participant);
      });
    }
  });
});

//Delete
router.delete('/delete_participant/:id', function(req, res) {
  models.Participant.destroy({
  where: {
      id: req.params.id
      }
    }).then(function(participant) {
    res.json(participant);
  });
});

router.delete('/delete_judge/:id', function(req, res) {
  models.Judge.destroy({
  where: {
      id: req.params.id
    }
    }).then(function(judge) {
    res.json(judge);
  });
});

router.delete('/delete_courtroom/:id', function(req, res) {
  models.Courtroom.destroy({
  where: {
      id: req.params.id
      }
    }).then(function(courtroom) {
    res.json(courtroom);
  });
});

router.delete('/delete_cases/:id', function(req, res) {
  models.Cases.destroy({
        where: {
      id: req.params.id
      }
    }).then(function(cases) {
    res.json(cases);
  });
});


module.exports = router;
