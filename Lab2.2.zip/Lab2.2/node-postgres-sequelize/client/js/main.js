// add scripts

$(document).on('ready', function() {
  console.log('sanity check!');
});
