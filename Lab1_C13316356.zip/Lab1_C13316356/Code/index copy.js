var express = require('express')
var app = express()
/*var http = require('http');
var massive = require("massive");
var connectionString = "postgres://massive:password@localhost/chinook";
var massiveInstance = massive.connectSync({connectionString : connectionString}) 

// Set a reference to the massive instance on Express' app:
app.set('db', massiveInstance);
http.createServer(app).listen(8080);
app.set('db', massiveInstance);
http.createServer(app).listen(8080);
var db = app.get('db');*/

app.get('/', function (req, res) {
  res.send('Hello World!')
})

app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})