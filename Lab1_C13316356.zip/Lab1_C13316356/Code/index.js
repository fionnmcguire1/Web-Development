var express = require('express')
var app = express()
var http = require('http');
var massive=require("massive");
var connectionString = "postgres://postgres:flames@localhost/pgguide";
var massiveInstance = massive.connectSync({connectionString : connectionString}) 

app.get('/users', function (req, res) {
massiveInstance.users.find({}, function(err,res1){
	var result = res1;
	res.send(result);   
  })
})

app.get('/users/:id', function (req, res) {
var id =req.param('id');
massiveInstance.users.find(Number(id), function(err,res1){
	var result = res1;
	res.send(result);   
  })
})

app.get('/products', function (req, res) {
massiveInstance.products.find({}, function(err,res1){
	var result = res1;
	res.send(result);   
  })
})

app.get('/products/:id', function (req, res) {
var id =req.param('id');
massiveInstance.products.find(Number(id), function(err,res1){
	var result = res1;
	res.send(result);   
  })
})


app.get('/purchases', function (req, res) {
massiveInstance.purchases.find({}, function(err,res1){
	var result = res1;
	res.send(result);   
  })
})


app.get('/purchases/:id', function (req, res) {
var id =req.param('id');
massiveInstance.purchases.find(Number(id), function(err,res1){
	var result = res1;
	res.send(result);   
  })
})


http.createServer(app).listen(8080);



